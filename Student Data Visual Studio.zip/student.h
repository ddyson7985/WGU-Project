#pragma once
#include <iostream>
#include <iomanip>
#include "degree.h"
using std::string;
using std::cout;
//using std::endl;

class Student
{


public:
    const static int daystoComplete = 3;

private:
	
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int ageofStudent;
	double daystoComp[daystoComplete];
	DegreeProgram degreeProgram;

public:

	Student();//Default Constructor
		Student (string studentID, string firstName, string lastName, string emailAddress, int ageofStudent, double daystoComp[], DegreeProgram degreeProgram);//Full Constructor
		~Student();/*Destructor*/

        //accessor aka getters
        string getID();
        string getfirstName();
        string getlastName();
        string getemailAddress();
        int getageofStudent();
        double getdaystoComp();
        DegreeProgram getdegreeProgram();

        //mutators aka setters
        void setID(string ID);
        void setfirstName(string firstName);
        void setlastName(string lastName);
        void setemailAddress(string emailAddress);
        void setageofStudent(int ageofStudent);
        void setdaystoComp(double daystoComp[]);
        void setDegree(DegreeProgram degreeProgram);
        
        static void printHeader();

        void print();

};

