#include "student.h"

Student::Student()//empty Constructor

{
	this->studentID = "";
	this->firstName = "";
	this->lastName = "";
	this->emailAddress = "";
	this->ageofStudent = 0;
	for (int i = 0; i < daystoComplete; i++) this->daystoComp[i] = 0;
	this->degreeProgram = DegreeProgram::NETWORK;

}

Student::Student(string studentID, string firstName, string lastName, string emailAddress, int ageofStudent, double daystoComp[], DegreeProgram degreeProgram);



	{
		this->studentID = studentID;
		this->firstName = firstName;
		this->lastName = lastName;
		this->emailAddress = emailAddress;
		this->ageofStudent = ageofStudent;
		for (int i = 0; i < daystoComp; i++) this->daystoComp[i] = daystoComp[i];
		this->degreeProgram = degreeProgram;
	}

	Student::Student() {}//Deconstructor

	//getters
	string Student::getID()
	{
		return this->studentID;

	}


	string Student::getfirstName()
	{
		return this->firstName;

	}

	string Student::getlastName()
	{
		return this->lastName;

	}

	string Student::getemailAddress()
	{

		return this->emailAddress;
	}

	int Student::getageofStudent()
	{

		return this->ageofStudent;

	}

	double* Student::getdaystoComp()
	{

		return this->daystoComp;

	}

	DegreeProgram Student::getdegreeProgram()
	{

		return this->degreeProgram;

	}


	//setters

	void Student::setID(string studentID)
	{
		this->studentID = studentID;

	}

	void Student::setfirstName(string firstName)
	{
		this->firstName = firstName;

	}

	void Student::setlastName(string lastName)
	{
		this->lastName = lastName;

	}

	void Student::setemailAddress(string emailAddress)
	{

		this->emailAddress = emailAddress;
	}

	void Student::ageofStudent(int ageofStudent)
	{
		this->ageofStudent = ageofStudent;

	}

	void Student::setdaystoComp(double daystoComp[])
	{
		this->daystoComp[0] = daystoComp[0];
		this->daystoComp[1] = daystoComp[1];
		this->daystoComp[2] = daystoComp[2];
	}

	void Student::setDegreeProgram(DegreeProgram dp) { this->degreeProgram = dp; }


	void Student::printHeader()//print's the header

	{
		cout << "Output format: StudentID|First Name|Last Name|Email Address|Age|Days to Complete Course\n";

	}

	void Student::print()

	{
		cout << this->getID() << '/t';
		cout << this->getfirstName() << '/t';
		cout << this->getlastName() << '/t';
		cout << this->getemailAddress() << '/t';
		cout << this->getageofStudent() << '/t';
		cout << this->getdaystoComp[0] << ',';
		cout << this->getdaystoComp[1] << ',';
		cout << this->getdaystoComp[2] << '/t';
		cout << degreeProgramStrings[this->getdegreeProgram()] << '\n';//Degree Program to string

	}

















